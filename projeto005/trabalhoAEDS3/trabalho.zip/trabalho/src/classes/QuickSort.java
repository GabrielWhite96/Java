package classes;

import java.time.LocalTime;

public class QuickSort {
  private LocalTime tempoInicial;
  private LocalTime tempoFinal;
  private int contAcesso=0;
  private int contTroca=0;
  private int contComp=0;
  
  public int partition(int array[], int low, int high) {
    int pivot = array[high];
    int i = (low - 1);
    for (int j = low; j < high; j++) {
      if (array[j] <= pivot) {
        i++;
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
        contTroca++;
        contAcesso+=5;
      }
      contComp++;
    }
    int temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;
    return (i + 1);
  }
  
  public void quickSort(int array[], int low, int high) {
    tempoInicial = LocalTime.now();
    if (low < high) {
      int pi = partition(array, low, high);
      quickSort(array, low, pi - 1);
      quickSort(array, pi + 1, high);
    }
    tempoFinal = LocalTime.now();
  }

  public void impConts(){
    System.out.println("Acesso: "+ this.contAcesso);
    System.out.println("Troca: " + this.contTroca);
    System.out.println("Comparação: " + this.contComp);
  }

  public void impTimer(){
    System.out.println("Timer: " + (tempoFinal.toNanoOfDay() - tempoInicial.toNanoOfDay())*1000000);
  }

}

